package steps;

import io.appium.java_client.AppiumBy;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import setup.StartStopServer;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class Steps extends StartStopServer {

    @Before("@setUp")
    public void setup() {
        runServer();
    }

//    @After("@setUp")
//    public void stop(){
//        tearDown();
//    }

    @Given("User is on {string} page")
    public void user_is_on_page(String page) {
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"" + page + "\")")).isDisplayed();
    }

    @Then("First product title is {string}")
    public void first_product_title_is(String title) {
        String element = driver.findElements(AppiumBy.androidUIAutomator(
                "description(\"store item text\")")).get(0).getText();
        assertEquals(element, title);
    }

    @When("user enters valid User name")
    public void userEntersValidUserName() {
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("bob@example.com");
    }

    @And("user enters valid password")
    public void userEntersValidPassword() {
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("10203040");
    }

    @When("User clicks Login button")
    public void clickLoginButton() {
        driver.findElements(AppiumBy.androidUIAutomator("className(\"android.widget.TextView\").text(\"Login\")")).get(1).click();
    }

    @Given("User is on login page")
    public void userIsOnLoginPage() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")).click();
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log In\")")).isDisplayed();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Log In\")")).click();
    }

    @When("user enters bad User name")
    public void userEntersBadUserName() {
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("mokinukas@testukas.com");
    }

    @Then("Error message about Bad credentials is displayed")
    public boolean errorMessageAboutBadUserNameIsDisplayed() {
        return driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Provided credentials do not match any user in this service.\")")).isDisplayed();
    }

    @And("user enters bad password")
    public void userEntersBadPassword() {
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("55555");
    }

    @Given("User is Logged in")
    public void userIsOnLoggedIn() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")).click();
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log In\")")).isDisplayed();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Log In\")")).click();
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("bob@example.com");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("10203040");
        driver.findElements(AppiumBy.androidUIAutomator("className(\"android.widget.TextView\").text(\"Login\")")).get(1).click();
    }

    @When("User clicks Menu button")
    public void userClicksMenuButton() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")).click();
    }

    @Then("Log Out is visible")
    public void logOutIsVisible() {
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log Out\")")).isDisplayed();
    }

    @When("user clicks Log Out")
    public void userClicksLogOut() {
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log Out\")")).click();
    }

    @Then("popup message “Are you sure you sure you want to logout?“ appears")
    public void popupMessageAreYouSureYouSureYouWantToLogoutAppears() {
        driver.findElement(AppiumBy.id("android:id/message")).isDisplayed();
    }

    @When("user clicks Log out button")
    public void userClicksLogOutButton() {
        driver.findElement(AppiumBy.id("android:id/button1")).click();
    }

    @Then("popup message “You are successfully logged out“ appears")
    public void popupMessageYouAreSuccessfullyLoggedOutAppears() {
        driver.findElement(AppiumBy.id("android:id/alertTitle")).isDisplayed();
    }


    @Given("Message Are you sure you sure you want to logout appears")
    public void messageAreYouSureYouSureYouWantToLogoutAppears() throws InterruptedException {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")).click();
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log In\")")).isDisplayed();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Log In\")")).click();
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("bob@example.com");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("10203040");
        driver.findElements(AppiumBy.androidUIAutomator("className(\"android.widget.TextView\").text(\"Login\")")).get(1).click();


        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(0)")).click();
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"Log Out\")")).click();
        driver.findElement(AppiumBy.androidUIAutomator(
                "new UiSelector().text(\"LOG OUT\")")).click();
        Thread.sleep(1000);
        driver.findElement(AppiumBy.id("android:id/alertTitle")).isDisplayed();
        Thread.sleep(3000);
    }

    @When("user clicks OK button")
    public void userClicksOKButton() {
        driver.findElement(AppiumBy.className("android.widget.Button")).click();
    }

    @When("user clicks Cancel")
    public void userClicksCancel() {
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.Button\").text(\"CANCEL\")")).click();
    }

    @Then("User is again on Login page")
    public void userIsStillOnLoginPage() {
        driver.findElements(AppiumBy.androidUIAutomator("className(\"android.widget.TextView\").text(\"Login\")")).get(0).isDisplayed();

    }

    @Given("User has {int} products in the cart")
    public void userHasProductsInTheCart(int product) {
        driver.findElements(AppiumBy.androidUIAutomator("new UiSelector().description(\"store item\")")).get(product).click();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Add To Cart\")")).click();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(2)")).click();
    }

    @When("User clicks on Proceed To Checkout")
    public void userClicksOnProceedToCheckout() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Proceed To Checkout\")")).click();
    }

    @When("User fills correct shipping address")
    public void userFillsCorreectShippingAddress() {
        driver.findElements(AppiumBy.className("android.widget.EditText"));
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("Rebeca Winter");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("Mandorley 112");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(3).sendKeys("Truro");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(5).sendKeys("89750");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(6).sendKeys("United Kingdom");
    }

    @And("clicks To Payment button")
    public void clicksToPaymentButton() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"To Payment\")")).click();
    }

    @Then("Enter a payment method page is displayed")
    public void enterAPaymentMethodPageIsDisplayed() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Checkout\")")).isDisplayed();
    }

    @Given("User is on the payment method window")
    public void userIsOnThePaymentMethodWindow() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Proceed To Checkout\")")).click();
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("Rebeca Winter");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("Mandorley 112");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(3).sendKeys("Truro");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(5).sendKeys("89750");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(6).sendKeys("United Kingdom");
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"To Payment\")")).click();
    }

    @When("User fills correct payment method")
    public void userFillsCorrectPaymentMethod() {
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(5)")).sendKeys("Rebecca Winter");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(8)")).sendKeys("325812657568789");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(12)")).sendKeys("03/25");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(13)")).sendKeys("123");
    }

    @And("clicks Review Order button")
    public void clicksReviewOrderButton() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Review Order\")")).click();

    }

    @Given("User is on Review Order page")
    public void userIsOnReviewOrderPage() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Proceed To Checkout\")")).click();
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("Rebeca Winter");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("Mandorley 112");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(3).sendKeys("Truro");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(5).sendKeys("89750");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(6).sendKeys("United Kingdom");
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"To Payment\")")).click();
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(5)")).sendKeys("Rebeca Winter");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(8)")).sendKeys("325812657568789");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(12)")).sendKeys("03/25");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(13)")).sendKeys("123");
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Review Order\")")).click();
    }

    @When("the user checks that the information is correct")
    public void theUserChecksThatTheInformationIsCorrect() {
        assertEquals("Rebeca Winter", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Rebeca Winter\")")).getText());
        assertEquals("Mandorley 112", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Mandorley 112\")")).getText());
        assertEquals("Truro", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Truro\")")).getText());
        assertEquals("United Kingdom, 89750", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"United Kingdom, 89750\")")).getText());
        assertEquals("3258 1265 7568 789", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"3258 1265 7568 789\")")).getText());
        assertEquals("Exp: 03/25", driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Exp: 03/25\")")).getText());
    }

    @And("clicks Pace Order button")
    public void clicksPaceOrderButton() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Place Order\")")).click();
    }

    @Then("message Checkout Complete is displayed")
    public void messageCheckoutCompleteIsDisplayed() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Checkout Complete\")")).isDisplayed();

    }

    @Given("User has completed checkout process")
    public void userHasCompletedCheckoutProcess() {
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Proceed To Checkout\")")).click();
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(0).sendKeys("Rebeca Winter");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(1).sendKeys("Mandorley 112");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(3).sendKeys("Truro");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(5).sendKeys("89750");
        driver.findElements(AppiumBy.className("android.widget.EditText")).get(6).sendKeys("United Kingdom");
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"To Payment\")")).click();
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(5)")).sendKeys("Rebeca Winter");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(8)")).sendKeys("325812657568789");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(12)")).sendKeys("03/25");
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.EditText\").index(13)")).sendKeys("123");
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Review Order\")")).click();
        driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Place Order\")")).click();
    }

    @When("User clicks Continue Shopping button")
    public void userClicksContinueShoppingButton() {
        driver.findElement(AppiumBy.androidUIAutomator("className(\"android.widget.TextView\").text(\"Continue Shopping\")")).click();
    }
}